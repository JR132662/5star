import React from 'react';
import Form from '../components/Form/Form';

function SignUp() {
	return (
		<>
			<Form />
		</>
	);
}

export default SignUp;
