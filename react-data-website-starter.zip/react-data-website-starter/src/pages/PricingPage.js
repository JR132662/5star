import React from 'react';
import Pricing from '../components/Pricing/Pricing';

const PricingPage = () => {
	return <Pricing />;
};

export default PricingPage;
